from random import randint
import turtle as t


num = 25
step = 1000

t.tracer(0, 0)
pool = [t.Turtle(shape='circle') for i in range(num)]
for unit in pool:
    unit.penup()
    unit.speed(50)
    unit.goto(randint(-300, 300), randint(-300, 300))
t.update()

for i in range(step):
    for unit in pool:
        t.tracer(0, 0)
        unit.forward(randint(5, 10))
        unit.right(randint(0, 360))
        t.update()
        
t.done()