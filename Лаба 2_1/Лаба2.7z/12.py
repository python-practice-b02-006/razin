import turtle as t

t.speed(10)
t.left(90)
for i in range(10):
    t.circle(-50, 180, 100)
    t.circle(-10, 180, 100)

t.done()