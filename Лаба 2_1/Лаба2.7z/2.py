import turtle as tl


tl.speed(50)
for i in range(359):
    tl.left(1)
    tl.forward(1.745240644)
tl.done()