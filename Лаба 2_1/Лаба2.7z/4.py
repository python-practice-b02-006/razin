import turtle as t

t.speed(10)
f = 14.14213562
x = f
for i in range(359):
    t.forward(2.094288722)
    t.right(1)
    
t.done()